---
layout: post
title: 'Serie de vídeos sobre o Vue.js 2.0'
main-class: 'dev'
date: 2016-10-03 00:15:00 
description: derscricao
color: '#637a91'
tags: vue2
layout: post
introduction: introducao
---

<iframe width="560" height="315" src="https://www.youtube.com/embed/zp8JIDNiAS4?list=PLFtCenSt_W2Fxgh1fjjwXK20qg2MdC2wp" frameborder="0" allowfullscreen></iframe>

---

### 1º aula

+ **Repositório do Curso** - https://github.com/Halfeld/vue-2-course

### 2º aula

+ **vue-cli** - https://github.com/vuejs/vue-cli

### 3º aula

+ **Cada propriedade do Vue Object(post do Vue.js brasil)** - http://www.vuejs-brasil.com.br/o-que-e-cada-propriedade-num-vue-object/

+ **Opções do createElement** - http://vuejs.org/guide/render-function.html#The-Data-Object-In-Depth

+ **Plugin para o JSX** - https://github.com/vuejs/babel-plugin-transform-vue-jsx

### 4º aula

+ **Moment.js** -  http://momentjs.com/
+ **Accounting.js** - http://openexchangerates.github.io/accounting.js/

### 5º aula

+ **Post sobre como funciona a reatividade no Vue** + http://www.vuejs-brasil.com.br/como-funciona-a-reatividade-no-vue-js/

### 6º aula

+ **Exemplo do debounce na documentação** - https://vuejs.org/guide/migration.html#v-model-with-debounce-deprecated

+ **OrderBy do lodash** - https://lodash.com/docs/4.16.2#orderBy

+ **Post do vuejs brasil** - http://www.vuejs-brasil.com.br/vue-js-2-filtros-em-listas/
