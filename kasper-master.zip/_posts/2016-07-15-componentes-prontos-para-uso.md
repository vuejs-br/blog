---
layout: post
title: 'Componentes prontos para uso'
main-class: 'dev'
date: 2016-07-15 12:17:34 
description: derscricao
color: '#637a91'
tags: 
layout: post
introduction: introducao
---

Lista de componentes prontos para uso ou simples para estudo de caso.


####Lista de Telefones
por [Vedovelli](/author/vedovelli)

<iframe width="100%" height="450" src="//jsfiddle.net/vedovelli/tL99rc7n/embedded/js,html,result/" allowfullscreen="allowfullscreen" frameborder="0"></iframe>
