---
layout: post
title: 'Gravação do 2º Hangout Vue.js Brasil'
main-class: 'dev'
date: 2016-07-29 02:09:27 
description: derscricao
color: '#637a91'
tags: 
layout: post
introduction: introducao
---

Hangout realizado em 28 de Julho de 2016.

<iframe width="560" height="315" src="https://www.youtube.com/embed/1MEY74BY_Ds" frameborder="0" allowfullscreen></iframe>

**Links**

***Vue-router***

Documentação oficial: http://router.vuejs.org/en/index.html
Código-fonte escrito durante o hangout: https://github.com/vuejs-br/2-hangout-vue-router

***Vue 2.0***

Issue com as features do Vue2: https://github.com/vuejs/vue/issues/2873
A documentação que temos até o momento: https://github.com/vuejs/vuejs.org/tree/2.0/src/guide
Plugin para o JSX: https://github.com/vuejs/babel-plugin-transform-vue-jsx
Server Side Redering: https://www.npmjs.com/package/vue-server-renderer
