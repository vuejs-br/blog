---
layout: post
title: 'Vedobot, um bot para o Slack!'
main-class: 'dev'
date: 2016-08-01 17:33:06 
description: derscricao
color: '#637a91'
tags: vue-js
 -bot
 -slack
layout: post
introduction: introducao
---

A comunidade do Vue aqui no Brasil vem crescendo bastante, a galera conversa bastante nos grupos, posts saindo a todo momento, projetos sendo criados, enfim... tá uma loucura =D

Para organizar ainda mais essa coisa linda, agora temos um Bot no slack que acaba sendo onde esta a maioria das pessoas e onde por consequência existem mais interações. 

![](/content/images/2016/08/vedovelli.png)

Esse bot no momento traz grande features para autores, mas uma coisa bacana que ele faz é ter a possibilidade de dar uma sugestão de post! Agora basta colocar a sugestão, algum dos autores vai ver e colocar em produção, e além disso você também pode votar em sugestões de temas e ver a data de próximos posts.

> Sem falar que o poder dele é mais de 8000 :D

veja todos os comandos com `@vedobot ajuda`

> E todos os comandos estão disponíveis em inglês também, para quem tem problemas com a acentuação do teclado ;)

Incrível, ele ainda esta em beta, mas qualquer bug, sugestão ou dica, crie um issue no [repositório](https://github.com/vuejs-br/vedobot) dele ou até mesmo faça a correção :D

> Como o bot esta em beta, olhem o comando certinho antes de executar para evitar undefined

É isso aí pessoal!
