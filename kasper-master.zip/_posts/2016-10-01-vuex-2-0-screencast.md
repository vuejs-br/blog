---
layout: post
title: 'Vuex 2.0 - screencast'
main-class: 'dev'
date: 2016-10-01 15:50:57 
description: derscricao
color: '#637a91'
tags: 
layout: post
introduction: introducao
---

São 40 minutos para aprender a configurar e utilizar o Vuex em seus projetos Vue.js.

<iframe width="560" height="315" src="https://www.youtube.com/embed/BT1kKaZwPRs" frameborder="0" allowfullscreen></iframe>
