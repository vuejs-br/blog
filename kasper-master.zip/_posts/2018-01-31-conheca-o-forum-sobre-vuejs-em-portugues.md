---
layout: post
title: 'Conheça o Fórum sobre Vuejs em português'
main-class: 'dev'
date: 2018-01-31 23:52:47 
description: derscricao
color: '#637a91'
tags: 
layout: post
introduction: introducao
---

O Vue.js BR precisa de um fórum! Tópicos com dúvidas e dicas são bem vindos aos motores de busca se estiverem em um formato fácil de ver! É por isso que suas dúvidas no google sempre trazem páginas como o Stackoverflow, GitHub Issues, entre outros, e quase não trazem algo relativo a um grupo do facebook por exemplo, ou uma conversa no Slack. 

A necessidade da criação de um fórum sobre Vue.js vem através do seu crescimento aqui em terras tupiniquins. Podemos usar as ferramentas do GitHub e criar facilmente um fórum. O processo de criação não levou 1 hora (e a hospedagem é gratuita). 

É muito fácil acessar o Fórum, basta acessar https://github.com/vuejs-br/forum

Para criar um tópico, clique na abinha Issues e adicione uma! Simples e fácil ! 

Enjoy !


