---
layout: post
title: 'Gravação do 1º Hangout Vue.js Brasil'
main-class: 'dev'
date: 2016-06-28 11:24:45 
description: derscricao
color: '#637a91'
tags: eventos
layout: post
introduction: introducao
---

Hangout realizado em 25 de Junho de 2016.

<iframe width="560" height="315" src="https://www.youtube.com/embed/gxiia9lQ3Ac" frameborder="0" allowfullscreen></iframe>
