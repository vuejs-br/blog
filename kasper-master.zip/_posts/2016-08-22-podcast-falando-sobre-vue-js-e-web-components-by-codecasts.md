---
layout: post
title: 'Podcast - Falando sobre Vue.JS e Web Components by CODECASTS'
main-class: 'dev'
date: 2016-08-22 18:34:20 
description: derscricao
color: '#637a91'
tags: podcasts
 -vue
 -web-components
 -vue-js-2
layout: post
introduction: introducao
---

<iframe width="100%" height="450" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/278908423&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>

Tudo que você queria saber sobre VueJS e Web Components, mas estava com vergonha de perguntar!

- [https://codecasts.com.br/podcast/2-falando-sobre-vuejs-e-web-components](https://codecasts.com.br/podcast/2-falando-sobre-vuejs-e-web-components)
- [https://soundcloud.com/codecasts/2-falando-sobre-vuejs-e-web-components](https://soundcloud.com/codecasts/2-falando-sobre-vuejs-e-web-components)

----

Por [codecasts.com.br](https://codecasts.com.br)
